import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-third-first',
  templateUrl: './third-first.component.html',
  styleUrls: ['./third-first.component.css']
})
export class ThirdFirstComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
