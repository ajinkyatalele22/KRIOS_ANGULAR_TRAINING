import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThirdFirstComponent } from './third-first.component';

describe('ThirdFirstComponent', () => {
  let component: ThirdFirstComponent;
  let fixture: ComponentFixture<ThirdFirstComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThirdFirstComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThirdFirstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
