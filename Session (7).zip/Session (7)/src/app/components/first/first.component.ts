import { Component, OnInit } from '@angular/core';

class User {
  constructor(
    public name: string,
    public email: string,
    public phone: number,
    public topic: string,
    public timePreference: string,
    public subscribe: boolean
  ) { }
}

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
  topics = ['.Net core', 'Angular', 'JavaScript'];
  userModel = new User('Ajinkya Talele', 'ajinkyatalele22@gmail.com', 5556665566, 'default', 'morning', true);
  topicHasError = true;
  submitted = false;
  errorMsg = '';

  constructor() { }

  ngOnInit() {
    this.errorMsg = 'test';
  }

  validateTopic(value) {
    if (value === 'default') {
      this.topicHasError = true;
    } else {
      this.topicHasError = false;
    }
  }

  onSubmit() {
    console.log(this.userModel);

    this.submitted = true;
    // this._enrollmentService.enroll(this.userModel)
    //   .subscribe(
    //     response => console.log('Success!', response),
    //     error => this.errorMsg = error.statusText
    //   )
  }

  reloadPage() {
    window.location.reload();
  }
}
