import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bindings',
  templateUrl: './bindings.component.html',
  styleUrls: ['./bindings.component.css']
})
export class BindingsComponent implements OnInit {
  public name: string;
  public firstID: string;
  public className: string;
  public testBinding: string;
  constructor() { }

  ngOnInit() {
    this.name = 'Training Sessions';
    this.firstID = 'firstID';
    this.className = 'color-green';
    this.testBinding = '';
  }

  onClick(value) {
    console.log(value);
  }

  getAlert() {
    alert();
  }
}
