import { First } from './first';

describe('First', () => {
  it('should create an instance', () => {
    expect(new First()).toBeTruthy();
  });
});
