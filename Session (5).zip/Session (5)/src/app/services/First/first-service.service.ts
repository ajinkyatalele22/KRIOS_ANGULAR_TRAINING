import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IFirst } from 'src/app/models/First/first';
import { Observable } from 'rxjs/Observable';

@Injectable({
  providedIn: 'root'
})
export class FirstServiceService {

  constructor(
    private http: HttpClient
  ) { }

  // GetData() {
  //   return 'Response getting from service';
  // }

  GetData(): Observable<IFirst[]> {
    return this.http.get<IFirst[]>('https://jsonplaceholder.typicode.com/posts');
  }
}
