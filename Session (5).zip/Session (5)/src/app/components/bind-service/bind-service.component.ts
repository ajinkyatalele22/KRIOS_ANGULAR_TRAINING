import { Component, OnInit } from '@angular/core';
import { FirstServiceService } from 'src/app/services/First/first-service.service';


@Component({
  selector: 'app-bind-service',
  templateUrl: './bind-service.component.html',
  styleUrls: ['./bind-service.component.css']
})
export class BindServiceComponent implements OnInit {
  public responseData = [];

  constructor(
    private firstServiceService: FirstServiceService
  ) { }

  ngOnInit() {
    // this.firstServiceService.GetData();
    this.firstServiceService.GetData().subscribe(
      res => {
        console.log(res);
        this.responseData = res;
      },
      err => {
        console.log(err);
      }
    );
  }

}
