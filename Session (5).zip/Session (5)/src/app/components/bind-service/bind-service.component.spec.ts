import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BindServiceComponent } from './bind-service.component';

describe('BindServiceComponent', () => {
  let component: BindServiceComponent;
  let fixture: ComponentFixture<BindServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BindServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BindServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
