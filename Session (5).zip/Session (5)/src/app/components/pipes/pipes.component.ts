import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {
  public message = 'Hello from Training!';
  public jsonObject = {
    firstName: 'Ajinkya',
    hasMobile: true,
    mobile: '9000000000',
    email: 'ajinkyatalele22@gmail.com',
    id: 3
  };

  public currentDate = new Date();

  constructor() { }

  ngOnInit() {
  }

}
