import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bindings',
  templateUrl: './bindings.component.html',
  styleUrls: ['./bindings.component.css']
})
export class BindingsComponent implements OnInit {
  public name: string;
  public firstID: string;
  public className: string;
  public testBinding: string;
  public checking: number
  public multiStyle = {
    color: 'blue',
    height: '50px',
    width: '50px',
    fontStyle: 'italic',
    fontWeight: 800,
    // border: '2px solid black'
  };

  constructor() { }

  ngOnInit() {
    this.name = 'Training Sessions';
    this.firstID = 'data12';
    this.className = 'color-green';
    this.testBinding = '';
    this.checking = 18;
  }

  onClick(value) {
    console.log(value);
  }

  getAlert() {
    alert();
  }
}
