import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-third-second',
  templateUrl: './third-second.component.html',
  styleUrls: ['./third-second.component.css']
})
export class ThirdSecondComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
